package com.cg.Payroll.Main;

import com.cg.Payroll.bean.*;
import com.cg.Payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.Payroll.services.PayrollServicesImpl;

public class MainClass {
	public static void main(String [] str){
		PayrollServicesImpl payrollservices= new PayrollServicesImpl();
	int i=payrollservices.acceptAssociateDetails("sai", "raghu", "raghu@gmail.com", "java", "Analyst", "10000", 100000, 100000, 1000, 1000, 1234, "scb", "10203030");
	System.out.println(payrollservices.getAssociatDetails(i).getFirstName());
	System.out.println(payrollservices.calculateNetSalary(i));
	System.out.println(payrollservices.getAssociatDetails(i).getSalary().getMonthlyTax());
	}
}