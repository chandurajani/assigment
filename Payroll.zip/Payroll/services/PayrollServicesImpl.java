package com.cg.Payroll.services;

import com.cg.Payroll.bean.Associate;
import com.cg.Payroll.bean.BankDetails;
import com.cg.Payroll.bean.Salary;
import com.cg.Payroll.daoservices.PayrollDAOServicesImpl;

public class PayrollServicesImpl {
	private PayrollDAOServicesImpl daoServices;
	public PayrollServicesImpl(){
		daoServices=new PayrollDAOServicesImpl();
	}
	public int acceptAssociateDetails(String firstName,String lastName,String emailId,String department,String designation,String pancard,
			int yearlyInvestmentUnder80C,float basicSalary,float epf, float companyPf,int accountNumber,String bankName,String ifscCode){
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}
	public float calculateNetSalary(int associateID){
		Associate associate = this.getAssociatDetails(associateID);
		if(associate!=null){
			float basicSalary=associate.getSalary().getBasicSalary(),i80C=associate.getYearlyInvestmentunder80c(), personalAllowances, conveyanceAllowance,otherAllowances,hra,gratuity,annualSalary,grossSalary,companyPf=associate.getSalary().getCompanyPf(),epf=associate.getSalary().getEpf();
			float a,tax,unTax;
			personalAllowances=(float) 0.3*basicSalary;
			conveyanceAllowance=(float)0.2*basicSalary;
			otherAllowances=(float)0.1*basicSalary;
			hra=(float)0.25*basicSalary;
			gratuity=(float)0.05*basicSalary;
			grossSalary=basicSalary+personalAllowances+conveyanceAllowance+otherAllowances+hra+companyPf;
			unTax=i80C+12*(companyPf+epf);
			associate.getSalary().setConveyenceAllowance(conveyanceAllowance);
			associate.getSalary().setGratuity(gratuity);
			associate.getSalary().setHra(hra);
			associate.getSalary().setOtherAllowance(otherAllowances);
			if(unTax>150000)
				unTax=150000;
			annualSalary=grossSalary*12;
			associate.getSalary().setGrossSalary(grossSalary);
			if(annualSalary<250000){
				associate.getSalary().setMonthlyTax(0);
				associate.getSalary().setNetSalary((annualSalary/12)-epf-companyPf);
				return ((annualSalary/12)-epf-companyPf);
			}
			else if (annualSalary>250000 && annualSalary<=500000){
				tax=(float)0.1*(annualSalary-250000-unTax);
				associate.getSalary().setMonthlyTax(tax/12);
				associate.getSalary().setNetSalary((annualSalary/12)-(tax/12)-epf-companyPf);
				return ((annualSalary/12)-(tax/12)-epf-companyPf);
			}
			else if(annualSalary>500000 && annualSalary<=1000000){
				a=(float)0.1*(250000-unTax);
				tax=(annualSalary-500000)*(float)0.2+a;
				associate.getSalary().setMonthlyTax(tax/12);
				associate.getSalary().setNetSalary((annualSalary/12)-(tax/12)-epf-companyPf);
				return ((annualSalary/12)-(tax/12)-epf-companyPf);
			}
			else if(annualSalary>1000000){
				int i=2;
				System.out.println(i);
				a=(float)0.1*(250000-unTax);
				tax=(float)0.3*(annualSalary-1000000)+a+100000;
				associate.getSalary().setMonthlyTax(tax/12);
				associate.getSalary().setNetSalary((annualSalary-tax)/12-epf-companyPf);
				return ((annualSalary-tax)/12-epf-companyPf);
			}
		}
		return 0;
	}
	public Associate getAssociatDetails(int associateID){
		return daoServices.getAssociate(associateID);
	}
	public Associate[] getAllAssociateDetails(){
		return null;
	}
}

