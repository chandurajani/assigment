package com.cg.Payroll.daoservices;

import com.cg.Payroll.bean.Associate;

public class PayrollDAOServicesImpl {
	private static Associate[] associatelist=new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=113;
	private static int ASSOCIATE_IDX_COUNTER=0;

	public int insertAssociate(Associate associate){
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associatelist[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateID();
	}

	public boolean updateAssocaite(Associate associate){
		for(int i=0;i<associatelist.length;i++)
			if(associatelist[i]!=null && associate.getAssociateID()==associatelist[i].getAssociateID())
				associatelist[i]=associate;

		return true;
	}
	public boolean deleteAssociate(int associateid){
		for(int i=0;i<associatelist.length;i++)
			if(associatelist[i]!=null && associateid==associatelist[i].getAssociateID()){
				associatelist[i]=null;
				return true;
			}
		return false;
	}
	public Associate getAssociate(int associateId){
		for(int i=0;i<associatelist.length;i++)
			if(associatelist[i]!=null && associateId==associatelist[i].getAssociateID())
				return associatelist[i];
		return null;
	}
	public Associate[] getAssociate(){
		return associatelist;
	}
	
}
