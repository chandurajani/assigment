package com.cg.Payroll.daoservices;

import com.cg.Payroll.bean.Associate;

public class PayrollDAOServiceImpl {

	public int insertAssociate(Associate associate) {
		// TODO Auto-generated method stub
		return 0;
	}

	public Associate getAssociate(int associateId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Associate[] getAssociate() {
		// TODO Auto-generated method stub
		return null;
	}

}
